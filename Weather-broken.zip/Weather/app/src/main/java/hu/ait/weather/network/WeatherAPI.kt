package hu.ait.weather.network

import hu.ait.weather.data.Base
import hu.ait.weather.data.WeatherResult
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query


// URL: https://api.exchangeratesapi.io/latest?base=USD
// HOST: https://api.exchangeratesapi.io
//
// PATH: /latest
//
// QUERY param separator: ?
// QUERY params: base

interface WeatherAPI {
    @GET("data/2.5/weather")
    fun getWeatherDetails(@Query("q") city: String,
                          @Query("units") units: String,
                          @Query("appid") appid: String): Call<Base>
}