package hu.ait.weather

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.bumptech.glide.Glide
import hu.ait.weather.data.Base
import hu.ait.weather.network.WeatherAPI
import kotlinx.android.synthetic.main.activity_details.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class DetailsActivity : AppCompatActivity() {

    val KEY_NAME:String = "KEY_NAME"
    private val HOST_URL = "https://api.openweathermap.org/"
    lateinit var cityName:String


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        if (intent.hasExtra(KEY_NAME)){
            tvCityName.text = intent.getStringExtra(KEY_NAME)
            cityName = intent.getStringExtra(KEY_NAME)
        }

        var retrofit = Retrofit.Builder()
            .baseUrl(HOST_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        var weatherAPI = retrofit.create(WeatherAPI::class.java)


        val call = weatherAPI.getWeatherDetails(cityName,
            "metric",
            "dfc0efd5510960abca605f1c712eda84"
        )

        Log.d("CALL", "CALL MADE")

        //call.execute()

        //Log.d("CALL", "CALL EXECUTED")

        call.enqueue(object : Callback<Base> {
            override fun onResponse(call: Call<Base>, response: Response<Base>) {
                Log.d("CALL", "ONRESPONSE")
                val weatherResult = response.body()
                tvTemperature.text =
                    String.format("%.2f", weatherResult?.main?.temp?.toFloat()) + "° C"
                tvDescription.text =
                        weatherResult?.weather?.get(0)?.description
                tvMinTemp.text =
                    "Low: ${String.format("%.2f", weatherResult?.main?.temp_min?.toFloat())}° C"
                tvMaxTemp.text =
                    "High: ${String.format("%.2f", weatherResult?.main?.temp_max?.toFloat())}° C"
                tvHumidity.text =
                    "Humidity: ${String.format("%.2f", weatherResult?.main?.humidity?.toFloat())}"
                tvSpeed.text =
                    "${String.format("%.2f", weatherResult?.wind?.speed?.toFloat())} m/s"

                Glide.with(this@DetailsActivity)
                    .load(
                        ("https://openweathermap.org/img/w/" +
                                response.body()?.weather?.get(0)?.icon
                                + ".png"))
                    .into(ivWeather)
            }
            override fun onFailure(call: Call<Base>, t: Throwable) {
                Log.d("CALL", "ONFAILURE")
                tvTemperature.text = "Could not obtain weather data"
                tvDescription.text = ""
                tvMinTemp.text = ""
                tvMaxTemp.text = ""
                tvHumidity.text = ""
                tvSpeed.text = ""
            }
        })


    }
}