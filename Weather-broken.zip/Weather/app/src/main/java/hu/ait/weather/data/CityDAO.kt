package hu.ait.weather.data

import android.arch.persistence.room.*


@Dao
interface CityDAO {
    @Query("SELECT * FROM cities")
    fun getAllItems(): List<City>

    @Insert
    fun insertItem(todo: City): Long

    @Delete
    fun deleteItem(todo: City)

    @Update
    fun updateItem(todo: City)

    @Query("DELETE FROM cities")
    fun deleteAll()
}