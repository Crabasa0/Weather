package hu.ait.weather


import android.app.Dialog
import android.content.ClipDescription
import android.content.Context
import android.os.Bundle
import android.support.v4.app.DialogFragment
import android.support.v7.app.AlertDialog
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import hu.ait.weather.data.City
import kotlinx.android.synthetic.main.new_city_dialog.*
import kotlinx.android.synthetic.main.new_city_dialog.view.*
import java.lang.NumberFormatException
import java.lang.RuntimeException
import java.util.*

class CityDialog : DialogFragment() {

    interface ItemHandler {
        fun itemCreated(item: City)
        fun itemUpdated(item: City)
    }

    private lateinit var todoHandler: ItemHandler

    override fun onAttach(context: Context?) {
        super.onAttach(context)

        if (context is ItemHandler) {
            todoHandler = context
        } else {
            throw RuntimeException(
                getString(R.string.no_itemHandlerInterface_str))
        }
    }

    private lateinit var etName: EditText



    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder = AlertDialog.Builder(requireContext())

        builder.setTitle(getString(R.string.dialog_title))

        val rootView = requireActivity().layoutInflater.inflate(
            R.layout.new_city_dialog, null
        )




        etName = rootView.etName
        builder.setView(rootView)

        val arguments = this.arguments
        if (arguments != null && arguments.containsKey(
                ScrollingActivity.KEY_ITEM_TO_EDIT)) {
            val todoItem = arguments.getSerializable(
                ScrollingActivity.KEY_ITEM_TO_EDIT
            ) as City
            etName.setText(todoItem.name)




            builder.setTitle(getString(R.string.dialog_title_edit))
        }

        builder.setPositiveButton(getString(R.string.ok_button_text)) {
                dialog, witch -> // empty
        }

        return builder.create()
    }


    override fun onResume() {
        super.onResume()

        val positiveButton = (dialog as AlertDialog).getButton(Dialog.BUTTON_POSITIVE)
        positiveButton.setOnClickListener {
            if (etName.text.isNotEmpty()) {
                val arguments = this.arguments
                if (arguments != null && arguments.containsKey(ScrollingActivity.KEY_ITEM_TO_EDIT)) {
                    handleItemEdit()
                } else {
                    handleItemCreate()
                }

                dialog.dismiss()
            } else {
                etName.error = getString(R.string.name_no_empty)
            }
        }
    }

    private fun handleItemCreate() {

        todoHandler.itemCreated(
            City(
                null,
                etName.text.toString()
            )
        )
    }

    private fun handleItemEdit() {
        val itemToEdit = arguments?.getSerializable(
            ScrollingActivity.KEY_ITEM_TO_EDIT
        ) as City
        itemToEdit.name = etName.text.toString()


        todoHandler.itemUpdated(itemToEdit)
    }





}
