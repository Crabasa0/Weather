package hu.ait.weather

import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import kotlinx.android.synthetic.main.activity_scrolling.*

import android.preference.PreferenceManager
import android.support.v7.app.AlertDialog
import android.support.v7.widget.DividerItemDecoration
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.StaggeredGridLayoutManager
import android.support.v7.widget.helper.ItemTouchHelper
import android.view.LayoutInflater
import android.view.MenuInflater
import android.widget.EditText
import hu.ait.weather.adapter.CityAdapter
import hu.ait.weather.data.AppDatabase
import hu.ait.weather.data.City
import hu.ait.weather.touch.CityReyclerTouchCallback
import hu.ait.weather.touch.CityTouchHelperCallback
import kotlinx.android.synthetic.main.activity_scrolling.*
import kotlinx.android.synthetic.main.new_city_dialog.view.*
import uk.co.samuelwall.materialtaptargetprompt.MaterialTapTargetPrompt
import java.util.*

class ScrollingActivity : AppCompatActivity(), CityDialog.ItemHandler {
    override fun itemCreated(city: City) {
        Thread {
            val todoId = AppDatabase.getInstance(
                this@ScrollingActivity).itemDao().insertItem(city)

            city.todoId = todoId

            runOnUiThread {
                todoAdapter.addTodo(city)
            }
        }.start()
    }

    override fun itemUpdated(item: City) {
        Thread {
            AppDatabase.getInstance(
                this@ScrollingActivity).itemDao().updateItem(item)

            runOnUiThread{
                todoAdapter.updateTodo(item, editIndex)
            }
        }.start()
    }

    lateinit var todoAdapter : CityAdapter

    companion object {
        val KEY_ITEM_TO_EDIT = "KEY_ITEM_TO_EDIT"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scrolling)

        setSupportActionBar(toolbar)

        fab.setOnClickListener { view ->
            //Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
            //    .setAction("Action", null).show()

            showAddTodoDialog()
        }

        fabDeleteAll.setOnClickListener{
            todoAdapter.deleteAll()
        }



        if (!wasOpenedEarlier()) {

            MaterialTapTargetPrompt.Builder(this)
                .setTarget(R.id.fab)
                .setPrimaryText(getString(R.string.new_item_tutorial_header))
                .setSecondaryText(getString(R.string.new_item_tutorial_text))
                .show()
        }

        saveFirstOpenInfo()

        initRecylerViewFromDB()

    }

    fun saveFirstOpenInfo() {
        var sharedPref = PreferenceManager.getDefaultSharedPreferences(this)
        var editor = sharedPref.edit()
        editor.putBoolean("KEY_WAS_OPEN", true)
        editor.apply()
    }

    fun wasOpenedEarlier() : Boolean {
        var sharedPref = PreferenceManager.getDefaultSharedPreferences(this)

        return sharedPref.getBoolean("KEY_WAS_OPEN", false)
    }




    private fun initRecylerViewFromDB() {
        Thread {
            var listTodos =
                AppDatabase.getInstance(this@ScrollingActivity).itemDao().getAllItems()

            runOnUiThread {
                // UI code here
                todoAdapter = CityAdapter(this, listTodos)

                recyclerItem.layoutManager = LinearLayoutManager(this)

                //recyclerTodo.layoutManager = GridLayoutManager(this, 2)
                //recyclerTodo.layoutManager = StaggeredGridLayoutManager(2,
                //    StaggeredGridLayoutManager.VERTICAL)
                recyclerItem.adapter = todoAdapter

                val itemDecoration = DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
                recyclerItem.addItemDecoration(itemDecoration)

                val callback = CityReyclerTouchCallback(todoAdapter)
                val touchHelper = ItemTouchHelper(callback)
                touchHelper.attachToRecyclerView(recyclerItem)
            }

        }.start()
    }

    private fun showAddTodoDialog() {
        CityDialog().show(supportFragmentManager, "TAG_TODO")
    }

    var editIndex: Int = -1

    public fun showEditTodoDialog(todoToEdit: City, idx: Int) {
        editIndex = idx
        val editItemDialog = CityDialog()

        val bundle = Bundle()
        bundle.putSerializable(KEY_ITEM_TO_EDIT, todoToEdit)
        editItemDialog.arguments = bundle

        editItemDialog.show(supportFragmentManager,
            "EDITITEMDIALOG")
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_scrolling, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return super.onOptionsItemSelected(item)
        /*
        return when (item.itemId) {
            R.id.action_deleteAll -> {
                todoAdapter.deleteAll()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
        */
    }
}